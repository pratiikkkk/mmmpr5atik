
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Layout, 
  Building2, 
  GitBranch, 
  ShieldCheck, 
  UserPlus, 
  LogIn, 
  Activity, 
  Search, 
  Plus, 
  List, 
  Save, 
  Edit, 
  CheckSquare, 
  Square, 
  CheckCircle2, 
  AlertCircle, 
  Hash, 
  Navigation, 
  Globe, 
  Calendar,
  Code,
  MoreHorizontal,
  FileText,
  Database
} from 'lucide-react';
import { TabType, Role, Company, Branch, Employee } from './types';

const APP_SCREENS = [
  'Overview', 'Company Master', 'Branch Master', 'Role Master', 'Employee Master',
  'Punch Desk', 'Reports Console', 'System Logs', 'Audit Trails'
];

// Helper for UI Trace (SQL Query Visualizer)
const OracleQueryBlock = ({ query }: { query: string }) => (
  <div className="bg-zinc-950 border border-white/5 rounded-2xl p-6 font-mono text-[10px] text-emerald-400/70 overflow-x-auto shadow-inner group mt-6">
     <div className="flex items-center gap-2 mb-3 text-white/20 uppercase tracking-widest text-[9px] font-bold">
       <Code size={12} /> SQL Execution Trace
     </div>
     <pre className="whitespace-pre-wrap">{query}</pre>
  </div>
);

const GlassForm = ({ title, icon: Icon, subtitle, children, viewMode, setViewMode, handleSaveMaster, isEditingId, resetForm }: any) => (
  <div className="animate-in fade-in zoom-in-95 duration-500 ease-out">
    <div className="backdrop-blur-3xl bg-white/5 border border-white/10 rounded-[2.5rem] shadow-2xl overflow-hidden relative">
      <div className="px-8 py-6 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 border-b border-white/5 bg-white/[0.02]">
        <div className="flex items-center gap-4">
          <div className="bg-blue-600/20 p-2 rounded-xl border border-blue-500/20">
            <Icon size={20} className="text-blue-400" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white uppercase tracking-tight">{title}</h2>
            <p className="text-[9px] text-white/30 uppercase tracking-[0.2em] font-bold">{subtitle}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => { setViewMode('LIST'); resetForm(); }}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all border ${viewMode === 'LIST' ? 'bg-blue-600 border-blue-500 shadow-lg' : 'bg-white/5 border-white/10 hover:bg-white/10'}`}
          >
            <List size={14}/> List View
          </button>
          <button 
            onClick={() => { setViewMode('FORM'); resetForm(); }}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all border ${viewMode === 'FORM' && !isEditingId ? 'bg-blue-600 border-blue-500 shadow-lg' : 'bg-white/5 border-white/10 hover:bg-white/10'}`}
          >
            <Plus size={14}/> New Record
          </button>
          <div className="h-8 w-px bg-white/10 mx-2"></div>
          <button 
            onClick={handleSaveMaster}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-600/20 active:scale-95 border border-emerald-500/30"
          >
            <Save size={14} /> {isEditingId ? 'Update' : 'Save'}
          </button>
        </div>
      </div>
      <div className="p-8 lg:p-12">{children}</div>
    </div>
  </div>
);

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>(TabType.OVERVIEW);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [viewMode, setViewMode] = useState<'FORM' | 'LIST'>('FORM');
  const [showToast, setShowToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // --- DATA REGISTRIES ---
  const [companiesList, setCompaniesList] = useState<Company[]>([
    { company_id: 'C1', company_name: 'Kotecha sarl', company_code: 'KOT' },
    { company_id: 'C2', company_name: 'KBS Solutions India', company_code: 'KBS' }
  ]);
  const [branchesList, setBranchesList] = useState<Branch[]>([
    { branch_id: 'B1', branch_name: 'Main HQ Mumbai', company_id: 'C1' },
    { branch_id: 'B2', branch_name: 'Paris Branch', company_id: 'C1' }
  ]);
  const [rolesList, setRolesList] = useState<Role[]>([
    { role_id: 'ROL_1', role_name: 'Admin', assigned_screens: APP_SCREENS, assigned_company_ids: ['C1'], is_active: true },
    { role_id: 'ROL_2', role_name: 'Supervisor', assigned_screens: ['Overview'], assigned_company_ids: ['C1', 'C2'], is_active: true }
  ]);
  const [employeesList, setEmployeesList] = useState<Employee[]>([
    { emp_id: 'KOT/API/0001', emp_name: 'Pratik Sharma', company_id: 'C1', branch_id: 'B1', gender: 'Male', biometric_id: 'B-001', erp_user_id: 'ERP-001', is_inactive: false, inactive_date: '', assigned_role_ids: ['ROL_1'] }
  ]);

  // --- FORM INPUT STATES ---
  const [isEditingId, setIsEditingId] = useState<string | null>(null);
  
  // Role Form
  const [roleNameInput, setRoleNameInput] = useState('');
  const [roleScreens, setRoleScreens] = useState<string[]>(['Overview']);
  const [roleCompanies, setRoleCompanies] = useState<string[]>([]);

  // Employee Form (Matching screenshot layout)
  const [empCompany, setEmpCompany] = useState('');
  const [empBranch, setEmpBranch] = useState('');
  const [empName, setEmpName] = useState('');
  const [empGender, setEmpGender] = useState('Male');
  const [empBioId, setEmpBioId] = useState('');
  const [empErpId, setEmpErpId] = useState('');
  const [empIsInactive, setEmpIsInactive] = useState(false);
  const [empInactDate, setEmpInactDate] = useState('');
  const [empRoles, setEmpRoles] = useState<string[]>([]);

  // Company Form
  const [compNameInput, setCompNameInput] = useState('');
  
  // Branch Form
  const [brNameInput, setBrNameInput] = useState('');
  const [brParentComp, setBrParentComp] = useState('');

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const notify = (msg: string, type: 'success' | 'error' = 'success') => {
    setShowToast({ message: msg, type });
    setTimeout(() => setShowToast(null), 3000);
  };

  const resetAllFields = () => {
    setIsEditingId(null);
    setRoleNameInput(''); setRoleScreens(['Overview']); setRoleCompanies([]);
    setEmpCompany(''); setEmpBranch(''); setEmpName(''); setEmpGender('Male');
    setEmpBioId(''); setEmpErpId(''); setEmpIsInactive(false); setEmpInactDate(''); setEmpRoles([]);
    setCompNameInput(''); setBrNameInput(''); setBrParentComp('');
  };

  const handleSaveMaster = () => {
    if (activeTab === TabType.ROLE_MASTER) {
      if (!roleNameInput.trim()) return notify("Role Designation is required", "error");
      if (roleCompanies.length === 0) return notify("Link at least one company", "error");
      const id = isEditingId || `ROL_${Date.now()}`;
      const updated = { role_id: id, role_name: roleNameInput, assigned_screens: roleScreens, assigned_company_ids: roleCompanies, is_active: true };
      if (isEditingId) setRolesList(prev => prev.map(r => r.role_id === id ? updated : r));
      else setRolesList([updated, ...rolesList]);
      notify("Role Synchronized");
    } 
    else if (activeTab === TabType.EMP_MASTER) {
      if (!empName.trim()) return notify("Employee Name is mandatory", "error");
      if (!empCompany) return notify("Company is mandatory", "error");
      if (empRoles.length === 0) return notify("Assign at least one role", "error");
      
      const compObj = companiesList.find(c => c.company_id === empCompany);
      const id = isEditingId || `${compObj?.company_code || 'KOT'}/API/${String(employeesList.length + 1).padStart(4, '0')}`;
      const updated = { emp_id: id, emp_name: empName, company_id: empCompany, branch_id: empBranch, gender: empGender, biometric_id: empBioId, erp_user_id: empErpId, is_inactive: empIsInactive, inactive_date: empInactDate, assigned_role_ids: empRoles };
      
      if (isEditingId) setEmployeesList(prev => prev.map(e => e.emp_id === id ? updated : e));
      else setEmployeesList([updated, ...employeesList]);
      notify("Employee Index Updated");
    }
    else if (activeTab === TabType.COMPANY_MASTER) {
      if (!compNameInput.trim()) return notify("Name required", "error");
      const id = `C${companiesList.length + 1}`;
      setCompaniesList([...companiesList, { company_id: id, company_name: compNameInput, company_code: compNameInput.substring(0,3).toUpperCase() }]);
      notify("Company Created");
    }
    else if (activeTab === TabType.BRANCH_MASTER) {
      if (!brNameInput.trim() || !brParentComp) return notify("All fields mandatory", "error");
      const id = `B${branchesList.length + 1}`;
      setBranchesList([...branchesList, { branch_id: id, branch_name: brNameInput, company_id: brParentComp }]);
      notify("Branch Linked");
    }
    resetAllFields();
    setViewMode('LIST');
  };

  const navTabs = [
    { id: TabType.OVERVIEW, name: 'Dashboard', icon: Layout },
    { id: TabType.COMPANY_MASTER, name: 'Company', icon: Building2 },
    { id: TabType.BRANCH_MASTER, name: 'Branch', icon: GitBranch },
    { id: TabType.ROLE_MASTER, name: 'Role', icon: ShieldCheck },
    { id: TabType.EMP_MASTER, name: 'Employee', icon: UserPlus },
    { id: TabType.MANUAL_ENTRY, name: 'Punch Desk', icon: LogIn },
    { id: TabType.REPORTS, name: 'Reports', icon: FileText }
  ];

  const filteredData = useMemo(() => {
    const q = searchQuery.toLowerCase();
    switch (activeTab) {
      case TabType.EMP_MASTER: return employeesList.filter(e => e.emp_name.toLowerCase().includes(q) || e.emp_id.toLowerCase().includes(q));
      case TabType.ROLE_MASTER: return rolesList.filter(r => r.role_name.toLowerCase().includes(q));
      case TabType.COMPANY_MASTER: return companiesList.filter(c => c.company_name.toLowerCase().includes(q));
      case TabType.BRANCH_MASTER: return branchesList.filter(b => b.branch_name.toLowerCase().includes(q));
      default: return [];
    }
  }, [searchQuery, employeesList, rolesList, companiesList, branchesList, activeTab]);

  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans selection:bg-blue-500/30 overflow-x-hidden pb-20">
      {showToast && (
        <div className="fixed top-32 left-1/2 -translate-x-1/2 z-[100] animate-in slide-in-from-top-4">
           <div className={`backdrop-blur-xl border px-8 py-4 rounded-[2rem] shadow-2xl flex items-center gap-4 ${showToast.type === 'error' ? 'bg-red-600/20 border-red-500/30' : 'bg-emerald-600/20 border-emerald-500/30'}`}>
              <AlertCircle className={showToast.type === 'error' ? 'text-red-400' : 'text-emerald-400'} size={18} />
              <span className="text-[10px] font-black uppercase tracking-[0.2em]">{showToast.message}</span>
           </div>
        </div>
      )}

      {/* Header */}
      <header className="sticky top-6 z-50 mx-auto max-w-7xl px-4">
        <div className="backdrop-blur-3xl bg-white/[0.03] border border-white/10 rounded-3xl px-8 h-20 flex justify-between items-center shadow-2xl">
          <div className="flex items-center gap-4">
            <Activity className="text-emerald-400 w-6 h-6" />
            <div>
              <h1 className="text-xl font-black uppercase tracking-tight">KBS Enterprise</h1>
              <p className="text-[8px] text-emerald-500/60 uppercase tracking-[0.4em] font-black">Oracle Data Node</p>
            </div>
          </div>
          <div className="flex items-center gap-8">
            <div className="text-right">
              <span className="text-[8px] text-white/20 uppercase font-black block tracking-widest">Network Time</span>
              <span className="text-sm font-mono text-white/80">{currentTime.toLocaleTimeString()}</span>
            </div>
            <div className="h-8 w-px bg-white/10 hidden md:block"></div>
            <div className="hidden md:flex items-center gap-3 bg-white/5 px-5 py-2 rounded-xl border border-white/10">
              <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-lg animate-pulse"></div>
              <span className="text-[9px] font-black uppercase tracking-widest text-white/50">Sys: Pratik</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-12">
        <nav className="flex justify-center mb-12 overflow-x-auto no-scrollbar scroll-smooth">
          <div className="bg-white/[0.02] backdrop-blur-2xl p-1.5 rounded-3xl border border-white/10 inline-flex shadow-xl">
            {navTabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id as TabType); setViewMode('FORM'); resetAllFields(); }}
                className={`flex items-center gap-2.5 px-6 py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all relative ${activeTab === tab.id ? 'bg-white/10 text-white shadow-lg' : 'text-white/25 hover:text-white/50'}`}
              >
                <tab.icon size={16} className={activeTab === tab.id ? 'text-blue-400' : ''} />
                <span>{tab.name}</span>
              </button>
            ))}
          </div>
        </nav>

        {/* DASHBOARD / OVERVIEW */}
        {activeTab === TabType.OVERVIEW && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 animate-in fade-in">
             <div className="backdrop-blur-3xl bg-white/5 border border-white/10 p-10 rounded-[3rem] shadow-xl space-y-6 group hover:border-blue-500/30 transition-all">
                <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-400 border border-blue-500/10 group-hover:scale-110 transition-transform"><Building2 size={24}/></div>
                <h3 className="text-lg font-black uppercase">Corporate Hub</h3>
                <p className="text-xs text-white/30 uppercase tracking-widest font-bold leading-relaxed">{companiesList.length} Entities currently indexed in the Oracle cluster.</p>
                <button onClick={() => setActiveTab(TabType.COMPANY_MASTER)} className="text-[10px] font-black text-blue-400 uppercase tracking-[0.3em] flex items-center gap-2 group/btn">Access Registry <Plus size={12} className="group-hover/btn:translate-x-1 transition-transform"/></button>
             </div>
             <div className="backdrop-blur-3xl bg-white/5 border border-white/10 p-10 rounded-[3rem] shadow-xl space-y-6 group hover:border-emerald-500/30 transition-all">
                <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-400 border border-emerald-500/10 group-hover:scale-110 transition-transform"><UserPlus size={24}/></div>
                <h3 className="text-lg font-black uppercase">Personnel Node</h3>
                <p className="text-xs text-white/30 uppercase tracking-widest font-bold leading-relaxed">{employeesList.length} Active personnel links synced with Biometric API.</p>
                <button onClick={() => setActiveTab(TabType.EMP_MASTER)} className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.3em] flex items-center gap-2 group/btn">Manage Personnel <Plus size={12} className="group-hover/btn:translate-x-1 transition-transform"/></button>
             </div>
             <div className="backdrop-blur-3xl bg-white/5 border border-white/10 p-10 rounded-[3rem] shadow-xl space-y-6 group hover:border-purple-500/30 transition-all">
                <div className="w-12 h-12 bg-purple-500/10 rounded-2xl flex items-center justify-center text-purple-400 border border-purple-500/10 group-hover:scale-110 transition-transform"><ShieldCheck size={24}/></div>
                <h3 className="text-lg font-black uppercase">Governance</h3>
                <p className="text-xs text-white/30 uppercase tracking-widest font-bold leading-relaxed">{rolesList.length} RBAC privilege profiles active across nodes.</p>
                <button onClick={() => setActiveTab(TabType.ROLE_MASTER)} className="text-[10px] font-black text-purple-400 uppercase tracking-[0.3em] flex items-center gap-2 group/btn">Security Policy <Plus size={12} className="group-hover/btn:translate-x-1 transition-transform"/></button>
             </div>
          </div>
        )}

        {/* EMPLOYEE MASTER (MATCHING SCREENSHOT) */}
        {activeTab === TabType.EMP_MASTER && (
          <GlassForm title="Employee Master (API)" icon={UserPlus} subtitle="Persistent Personnel Record" viewMode={viewMode} setViewMode={setViewMode} handleSaveMaster={handleSaveMaster} isEditingId={isEditingId} resetForm={resetAllFields}>
             {viewMode === 'LIST' ? (
                <div className="overflow-hidden rounded-3xl border border-white/10 bg-black/40 shadow-2xl">
                   <table className="w-full text-left">
                     <thead>
                       <tr className="bg-white/[0.03] text-[9px] font-black text-white/20 uppercase tracking-[0.4em]">
                         <th className="px-10 py-6">ID Node</th>
                         <th className="px-10 py-6">Name</th>
                         <th className="px-10 py-6">Entity Link</th>
                         <th className="px-10 py-6 text-right">Actions</th>
                       </tr>
                     </thead>
                     <tbody className="divide-y divide-white/5">
                        {filteredData.map((e: any) => (
                          <tr key={e.emp_id} className="hover:bg-white/[0.02] group">
                            <td className="px-10 py-6 font-mono text-xs text-blue-400 font-bold">{e.emp_id}</td>
                            <td className="px-10 py-6 text-sm font-black text-white/80 uppercase">{e.emp_name}</td>
                            <td className="px-10 py-6 text-[10px] font-bold text-white/30 uppercase">{companiesList.find(c => c.company_id === e.company_id)?.company_name}</td>
                            <td className="px-10 py-6 text-right">
                               <button onClick={() => {
                                 setIsEditingId(e.emp_id); setEmpName(e.emp_name); setEmpCompany(e.company_id); setEmpBranch(e.branch_id);
                                 setEmpGender(e.gender); setEmpBioId(e.biometric_id); setEmpErpId(e.erp_user_id); setEmpIsInactive(e.is_inactive);
                                 setEmpInactDate(e.inactive_date); setEmpRoles(e.assigned_role_ids); setViewMode('FORM');
                               }} className="p-2 bg-white/5 rounded-lg border border-white/10 text-white/40 hover:text-blue-400 transition-all"><Edit size={14}/></button>
                            </td>
                          </tr>
                        ))}
                     </tbody>
                   </table>
                </div>
             ) : (
                <div className="space-y-12">
                   {/* Layout matching user screenshot sequence */}
                   <div className="grid grid-cols-1 lg:grid-cols-3 gap-x-16 gap-y-10">
                      {/* Left Column (Main Data) */}
                      <div className="space-y-6">
                        <div className="space-y-2">
                           <label className="text-[11px] font-black text-white/40 uppercase tracking-widest">Company*</label>
                           <select className="w-full bg-white/[0.03] border border-white/10 rounded-2xl px-6 py-4 text-sm font-bold uppercase text-white outline-none focus:border-blue-500/50" value={empCompany} onChange={e => {setEmpCompany(e.target.value); setEmpBranch('');}}>
                              <option value="" className="bg-zinc-900">Select Entity</option>
                              {companiesList.map(c => <option key={c.company_id} value={c.company_id} className="bg-zinc-900">{c.company_name}</option>)}
                           </select>
                        </div>
                        <div className="space-y-2">
                           <label className="text-[11px] font-black text-white/40 uppercase tracking-widest">Branch</label>
                           <select className="w-full bg-white/[0.03] border border-white/10 rounded-2xl px-6 py-4 text-sm font-bold uppercase text-white outline-none focus:border-blue-500/50 disabled:opacity-20" disabled={!empCompany} value={empBranch} onChange={e => setEmpBranch(e.target.value)}>
                              <option value="" className="bg-zinc-900">Select Local Hub</option>
                              {branchesList.filter(b => b.company_id === empCompany).map(b => <option key={b.branch_id} value={b.branch_id} className="bg-zinc-900">{b.branch_name}</option>)}
                           </select>
                        </div>
                        <div className="space-y-2">
                           <label className="text-[11px] font-black text-white/40 uppercase tracking-widest">Employee No.*</label>
                           <div className="flex gap-2">
                              <input readOnly value={isEditingId || "AUTO_GEN_ID"} className="flex-1 bg-white/[0.02] border border-white/10 rounded-2xl px-6 py-4 text-sm font-mono text-white/20 cursor-not-allowed" />
                              <button className="bg-white/5 p-4 rounded-2xl border border-white/10 text-blue-400 hover:bg-white/10"><MoreHorizontal size={20}/></button>
                           </div>
                        </div>
                        <div className="space-y-2">
                           <label className="text-[11px] font-black text-white/40 uppercase tracking-widest">Employee Name*</label>
                           <input type="text" placeholder="ENTER NAME" className="w-full bg-white/[0.03] border border-white/10 rounded-2xl px-6 py-4 text-sm font-bold uppercase outline-none focus:border-blue-500/50" value={empName} onChange={e => setEmpName(e.target.value)} />
                        </div>
                        <div className="space-y-2">
                           <label className="text-[11px] font-black text-white/40 uppercase tracking-widest">Gender*</label>
                           <select className="w-full bg-white/[0.03] border border-white/10 rounded-2xl px-6 py-4 text-sm font-bold uppercase outline-none focus:border-blue-500/50" value={empGender} onChange={e => setEmpGender(e.target.value)}>
                              <option value="Male" className="bg-zinc-900">Male</option>
                              <option value="Female" className="bg-zinc-900">Female</option>
                              <option value="Other" className="bg-zinc-900">Other</option>
                           </select>
                        </div>
                      </div>

                      {/* Center Column (IDs & Roles) */}
                      <div className="space-y-6">
                        <div className="space-y-2">
                           <label className="text-[11px] font-black text-white/40 uppercase tracking-widest">Biometric ID</label>
                           <input type="text" className="w-full bg-white/[0.03] border border-white/10 rounded-2xl px-6 py-4 text-sm font-bold outline-none focus:border-blue-500/50" value={empBioId} onChange={e => setEmpBioId(e.target.value)} />
                        </div>
                        <div className="space-y-2">
                           <label className="text-[11px] font-black text-white/40 uppercase tracking-widest">ERP User ID</label>
                           <input type="text" className="w-full bg-white/[0.03] border border-white/10 rounded-2xl px-6 py-4 text-sm font-bold outline-none focus:border-blue-500/50" value={empErpId} onChange={e => setEmpErpId(e.target.value)} />
                        </div>
                        
                        <div className="pt-4 space-y-4">
                           <label className="text-[11px] font-black text-blue-400 uppercase tracking-widest block">Assign Multiple Roles*</label>
                           <div className="space-y-2 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                              {rolesList.map(r => (
                                <button key={r.role_id} onClick={() => setEmpRoles(prev => prev.includes(r.role_id) ? prev.filter(i => i !== r.role_id) : [...prev, r.role_id])} className={`w-full flex items-center justify-between p-4 rounded-xl border text-[10px] font-black uppercase transition-all ${empRoles.includes(r.role_id) ? 'bg-blue-600/20 border-blue-400 text-white' : 'bg-white/5 border-white/5 text-white/20 hover:border-white/20'}`}>
                                   {r.role_name} {empRoles.includes(r.role_id) ? <CheckSquare size={14}/> : <Square size={14}/>}
                                </button>
                              ))}
                           </div>
                        </div>
                      </div>

                      {/* Right Column (Status) */}
                      <div className="space-y-6">
                        <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10 space-y-8">
                           <div className="flex items-center gap-4">
                              <input type="checkbox" checked={empIsInactive} onChange={e => setEmpIsInactive(e.target.checked)} className="w-5 h-5 rounded bg-zinc-900 border-white/10 checked:bg-blue-600" />
                              <span className="text-[11px] font-black text-white/60 uppercase tracking-widest">Inactive Status</span>
                           </div>
                           <div className="space-y-2">
                              <label className="text-[10px] font-black text-white/30 uppercase tracking-widest">Inactivated Dt</label>
                              <div className="relative">
                                 <input type="date" disabled={!empIsInactive} className={`w-full bg-zinc-950 border border-white/5 rounded-2xl px-6 py-4 text-xs text-white outline-none focus:border-red-500/50 ${!empIsInactive ? 'opacity-20 cursor-not-allowed' : ''}`} value={empInactDate} onChange={e => setEmpInactDate(e.target.value)} />
                                 <Calendar className="absolute right-6 top-1/2 -translate-y-1/2 text-white/10" size={16}/>
                              </div>
                           </div>
                        </div>
                      </div>
                   </div>

                   <OracleQueryBlock query={`SELECT a.companyid, a.companyname, UPPER(SUBSTR(companyname,1,3)) code 
FROM company a, axuserscompany b, axusers c
WHERE a.companyid = b.company 
  AND b.axusersid = c.axusersid 
  AND c.pusername = :username 
ORDER BY 2`} />
                </div>
             )}
          </GlassForm>
        )}

        {/* ROLE MASTER */}
        {activeTab === TabType.ROLE_MASTER && (
          <GlassForm title="Role Governance" icon={ShieldCheck} subtitle="Access Level Management" viewMode={viewMode} setViewMode={setViewMode} handleSaveMaster={handleSaveMaster} isEditingId={isEditingId} resetForm={resetAllFields}>
            {viewMode === 'LIST' ? (
              <div className="overflow-hidden rounded-3xl border border-white/10 bg-black/40">
                 <table className="w-full text-left">
                   <thead>
                     <tr className="bg-white/[0.03] text-[9px] font-black text-white/20 uppercase tracking-[0.4em]">
                       <th className="px-10 py-6">Designation</th>
                       <th className="px-10 py-6">Linked Companies</th>
                       <th className="px-10 py-6 text-right">Actions</th>
                     </tr>
                   </thead>
                   <tbody className="divide-y divide-white/5">
                      {filteredData.map((r: any) => (
                        <tr key={r.role_id} className="hover:bg-white/[0.02]">
                          <td className="px-10 py-6 text-sm font-black text-white uppercase">{r.role_name}</td>
                          <td className="px-10 py-6">
                             <div className="flex gap-2">
                                {r.assigned_company_ids.map((cid: string) => (
                                  <span key={cid} className="px-2 py-1 bg-zinc-800 rounded text-[9px] font-bold text-white/30 uppercase tracking-widest">
                                    {companiesList.find(c => c.company_id === cid)?.company_code}
                                  </span>
                                ))}
                             </div>
                          </td>
                          <td className="px-10 py-6 text-right">
                             <button onClick={() => { setIsEditingId(r.role_id); setRoleNameInput(r.role_name); setRoleScreens(r.assigned_screens); setRoleCompanies(r.assigned_company_ids); setViewMode('FORM'); }} className="p-2 bg-white/5 rounded-lg border border-white/10 hover:text-blue-400 transition-all"><Edit size={14}/></button>
                          </td>
                        </tr>
                      ))}
                   </tbody>
                 </table>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 animate-in fade-in">
                 <div className="space-y-10">
                    <div className="space-y-2">
                       <label className="text-xs font-black text-white/40 uppercase tracking-widest">Role Name*</label>
                       <input type="text" placeholder="E.G. REGIONAL HEAD" className="w-full bg-white/[0.03] border border-white/10 rounded-2xl px-6 py-5 text-sm font-bold uppercase outline-none focus:border-blue-500/50" value={roleNameInput} onChange={e => setRoleNameInput(e.target.value)} />
                    </div>
                    <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10">
                       <label className="text-[11px] font-black text-emerald-400 uppercase tracking-widest block mb-6">Link Multiple Companies*</label>
                       <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {companiesList.map(c => (
                            <button key={c.company_id} onClick={() => setRoleCompanies(prev => prev.includes(c.company_id) ? prev.filter(i => i !== c.company_id) : [...prev, c.company_id])} className={`flex items-center justify-between p-4 rounded-xl border text-[10px] font-black uppercase transition-all ${roleCompanies.includes(c.company_id) ? 'bg-emerald-600/20 border-emerald-400 text-white' : 'bg-white/5 border-white/5 text-white/20'}`}>
                               {c.company_name} {roleCompanies.includes(c.company_id) ? <CheckSquare size={14}/> : <Square size={14}/>}
                            </button>
                          ))}
                       </div>
                    </div>
                 </div>
                 <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10">
                    <label className="text-[11px] font-black text-blue-400 uppercase tracking-widest block mb-6">Module Permissions</label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-80 overflow-y-auto pr-2 custom-scrollbar">
                       {APP_SCREENS.map(scr => (
                          <button key={scr} onClick={() => setRoleScreens(prev => prev.includes(scr) ? prev.filter(s => s !== scr) : [...prev, scr])} className={`flex items-center justify-between p-4 rounded-xl border text-[10px] font-black uppercase transition-all ${roleScreens.includes(scr) ? 'bg-blue-600/20 border-blue-400 text-white' : 'bg-white/5 border-white/5 text-white/20 hover:border-white/20'}`}>
                             {scr} {roleScreens.includes(scr) ? <CheckSquare size={14}/> : <Square size={14}/>}
                          </button>
                       ))}
                    </div>
                 </div>
              </div>
            )}
          </GlassForm>
        )}

        {/* PUNCH DESK */}
        {activeTab === TabType.MANUAL_ENTRY && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 animate-in fade-in">
            <div className="lg:col-span-5">
              <div className="backdrop-blur-3xl bg-white/[0.03] border border-white/10 p-16 rounded-[4rem] shadow-2xl text-center space-y-12">
                <div className="space-y-4">
                  <p className="text-[11px] font-black text-white/20 uppercase tracking-[0.5em]">Network Station Hub</p>
                  <div className="text-8xl font-black text-white tabular-nums tracking-tighter">
                    {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-6">
                  <button onClick={() => notify("Punch In Captured")} className="bg-emerald-600 py-10 rounded-[2.5rem] font-black text-2xl uppercase tracking-widest shadow-2xl shadow-emerald-600/30 hover:bg-emerald-500 transition-all flex items-center justify-center gap-4 active:scale-95"><LogIn size={32}/>PUNCH IN</button>
                  <button onClick={() => notify("Punch Out Captured")} className="bg-white/5 border border-white/10 py-10 rounded-[2.5rem] font-black text-2xl uppercase tracking-widest text-white/30 hover:bg-white/10 transition-all flex items-center justify-center gap-4 active:scale-95"><LogIn size={32} className="rotate-180"/>PUNCH OUT</button>
                </div>
                <div className="flex items-center justify-center gap-8 pt-8">
                   <div className="flex items-center gap-3"><Navigation size={14} className="text-blue-500"/><span className="text-[9px] font-black text-white/20 uppercase tracking-widest">Main Hub</span></div>
                   <div className="flex items-center gap-3"><Globe size={14} className="text-emerald-500"/><span className="text-[9px] font-black text-white/20 uppercase tracking-widest">Active Node</span></div>
                </div>
              </div>
            </div>
            <div className="lg:col-span-7">
               <div className="backdrop-blur-2xl bg-white/[0.03] border border-white/10 rounded-[4rem] shadow-2xl h-full overflow-hidden">
                  <div className="p-10 border-b border-white/5 bg-white/[0.01] flex justify-between items-center">
                    <h3 className="text-2xl font-black uppercase tracking-tighter">Live Session Stream</h3>
                    <div className="text-[10px] font-black text-blue-400 flex items-center gap-2"><Activity size={14} className="animate-pulse"/> ENCRYPTED</div>
                  </div>
                  <div className="p-10 space-y-6">
                     {[1, 2, 3].map(i => (
                        <div key={i} className="flex justify-between items-center p-6 bg-white/[0.02] rounded-3xl border border-white/5">
                           <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-400 font-black text-xs">#{i}</div>
                              <span className="text-sm font-black uppercase text-white/80 tracking-tight">Oracle Node Capture #{7700+i}</span>
                           </div>
                           <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase">Authorized</span>
                        </div>
                     ))}
                  </div>
               </div>
            </div>
          </div>
        )}

        {/* RESTORED COMPANY/BRANCH MASTERS */}
        {(activeTab === TabType.COMPANY_MASTER || activeTab === TabType.BRANCH_MASTER) && (
          <GlassForm title={activeTab === TabType.COMPANY_MASTER ? "Company Master" : "Branch Master"} icon={activeTab === TabType.COMPANY_MASTER ? Building2 : GitBranch} subtitle="Node Infrastructure" viewMode={viewMode} setViewMode={setViewMode} handleSaveMaster={handleSaveMaster} isEditingId={isEditingId} resetForm={resetAllFields}>
             {viewMode === 'LIST' ? (
                <div className="overflow-hidden rounded-3xl border border-white/10 bg-black/40 shadow-2xl">
                   <table className="w-full text-left">
                     <thead>
                       <tr className="bg-white/[0.03] text-[9px] font-black text-white/20 uppercase tracking-[0.4em]">
                         <th className="px-10 py-8">Nomenclature</th>
                         <th className="px-10 py-8">Identifier</th>
                         <th className="px-10 py-8 text-right">Status</th>
                       </tr>
                     </thead>
                     <tbody className="divide-y divide-white/5">
                        {filteredData.map((d: any) => (
                          <tr key={d.company_id || d.branch_id} className="hover:bg-white/[0.02]">
                            <td className="px-10 py-8 text-sm font-black text-white uppercase">{d.company_name || d.branch_name}</td>
                            <td className="px-10 py-8 font-mono text-xs text-blue-400 font-bold">{d.company_id || d.branch_id}</td>
                            <td className="px-10 py-8 text-right"><span className="text-[9px] font-black text-emerald-500 uppercase px-3 py-1 bg-emerald-500/10 rounded-lg">Persistent</span></td>
                          </tr>
                        ))}
                     </tbody>
                   </table>
                </div>
             ) : (
                <div className="max-w-xl mx-auto space-y-10">
                   {activeTab === TabType.BRANCH_MASTER && (
                     <div className="space-y-2">
                        <label className="text-xs font-black text-white/40 uppercase tracking-widest">Parent Entity*</label>
                        <select className="w-full bg-white/[0.03] border border-white/10 rounded-2xl px-6 py-5 text-sm font-bold uppercase text-white outline-none focus:border-blue-500/50" value={brParentComp} onChange={e => setBrParentComp(e.target.value)}>
                           <option value="" className="bg-zinc-900">Select Corporate Owner</option>
                           {companiesList.map(c => <option key={c.company_id} value={c.company_id} className="bg-zinc-900">{c.company_name}</option>)}
                        </select>
                     </div>
                   )}
                   <div className="space-y-2">
                      <label className="text-xs font-black text-white/40 uppercase tracking-widest">Formal Name*</label>
                      <input type="text" placeholder="ENTER ENTITY NAME" className="w-full bg-white/[0.03] border border-white/10 rounded-2xl px-6 py-5 text-sm font-bold uppercase text-white outline-none focus:border-blue-500/50" value={activeTab === TabType.COMPANY_MASTER ? compNameInput : brNameInput} onChange={e => activeTab === TabType.COMPANY_MASTER ? setCompNameInput(e.target.value) : setBrNameInput(e.target.value)} />
                   </div>
                   <OracleQueryBlock query={activeTab === TabType.COMPANY_MASTER ? `INSERT INTO COMPANY (NAME, CODE) VALUES (:name, UPPER(SUBSTR(:name,1,3)))` : `INSERT INTO BRANCH (NAME, COMPANY_ID) VALUES (:name, :comp_id)`} />
                </div>
             )}
          </GlassForm>
        )}
      </main>

      {/* Persistent Footer */}
      <footer className="max-w-7xl mx-auto px-4 py-20 border-t border-white/5 mt-32 flex flex-col md:flex-row justify-between items-center gap-12">
        <div className="text-center md:text-left">
          <h5 className="text-[10px] font-black text-white/20 uppercase tracking-[0.6em] mb-2">KBS Enterprise Architecture v4.98</h5>
          <p className="text-[10px] text-white/40 font-black uppercase tracking-widest">© 2024 KBS Global Solutions • Oracle Cloud Node ORA-PD-22</p>
        </div>
        <div className="flex gap-12">
           <div className="text-center">
              <span className="text-[8px] font-black text-white/10 uppercase block mb-1 tracking-widest">Database</span>
              <span className="text-xs font-black text-emerald-500/60 uppercase">SQL-LINKED</span>
           </div>
           <div className="text-center">
              <span className="text-[8px] font-black text-white/10 uppercase block mb-1 tracking-widest">Privileges</span>
              <span className="text-xs font-black text-blue-500/60 uppercase">RBAC-STRICT</span>
           </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
