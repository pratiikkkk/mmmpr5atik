
export enum TabType {
  OVERVIEW = 'overview',
  COMPANY_MASTER = 'company-master',
  BRANCH_MASTER = 'branch-master',
  ROLE_MASTER = 'role-master',
  EMP_MASTER = 'emp-master',
  MANUAL_ENTRY = 'manual-entry',
  DATABASE = 'database',
  REPORTS = 'reports'
}

export interface Role {
  role_id: string;
  role_name: string;
  assigned_screens: string[];
  assigned_company_ids: string[];
  is_active: boolean;
}

export interface Company {
  company_id: string;
  company_name: string;
  company_code: string;
}

export interface Branch {
  branch_id: string;
  branch_name: string;
  company_id: string;
}

export interface Employee {
  emp_id: string;
  emp_name: string;
  company_id: string;
  branch_id: string;
  gender: string;
  biometric_id: string;
  erp_user_id: string;
  is_inactive: boolean;
  inactive_date: string;
  assigned_role_ids: string[];
}
